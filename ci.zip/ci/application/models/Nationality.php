<?php 

class Nationality extends CI_Model
{
    
    public function loadnationality()
    {
        return $this->db->select('*')->get('nationality')->result_array();
    }

    public function addnationality($data)
    {
        return $this->db->insert('nationality',$data);
    }
    public function updatenationality($data)
    {
        $this->db->where('id',$data['id']);
        return $this->db->update('nationality',$data);
    }


}



?>